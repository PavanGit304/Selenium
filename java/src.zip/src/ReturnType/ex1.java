package ReturnType;

public class ex1 {
/*return type : void it doesn't returns anything to the method OR 
if the return type other then the void then we much return that type of value */
	public static void main(String[] args) {

		ex1 obj = new ex1();
		int exe = obj.m1();
		System.out.println("a+b =" + exe);
	}

	public int m1() {
		int a = 10;
		int b = 20;
		int c = a + b;
		return c;
	}
}
