package typeCasting;

public class narrowingCasting //(manually) - converting a larger type to a smaller size type
{

	  public static void main(String[] args) {
		    double myDouble = 9.78d;
		    int myInt = (int) myDouble; // Manual casting: double to int

		    System.out.println(myDouble);   
		    System.out.println(myInt);      
		  }
}	
