package typeCasting;

// Type casting is when you assign a value of one primitive data type to another type.
public class wideningCasting// it (automatically) - converting a smaller type to a larger type size
{
	public static void main(String[] args) {
	    int a = 9;
	    double b= a; // Automatic casting: int to double

	    System.out.println(a);     
	    System.out.println(b);  
	  }

}