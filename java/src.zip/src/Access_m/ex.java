package Access_m;

public class ex {
	public  void m1()   // public Access modifier: it shares methods and members from any where like inside the class out class and inside package and outside the package 
	{
		
	    System.out.println("Hello World!"); 
	}

	private void m2()   //private Access modifier: it shares methods and members with in the class 
	{
		
	    System.out.println("Hello World!"); 
	}
	protected void m3()    //protected Access modifier:
	{
		
	    System.out.println("Hello World!"); 
	}
	 void m4()           //default Access modifier:it shares methods and members with in the class and packages 
	{
		
	    System.out.println("Hello World!"); 
	}
	

}
