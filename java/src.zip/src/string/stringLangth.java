package string;

public class stringLangth {
/*A String in Java is actually an object, which contain methods that can perform certain operations on strings. 
	For example, the length of a string can be found with the length() method:*/
	
	public static void main(String[] args) {
		
	    String txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	    System.out.println("The length of the txt string is: "
	    + txt.length());
	  }

}
