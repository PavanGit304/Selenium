package string;

public class stringConcatenation {
	//The + operator can be used between strings to combine them. This is called concatenation:

		  public static void main(String args[]) {
		    String firstName = "John";
		    String lastName = "Doe";
		    System.out.println(firstName + " " + lastName);
		  }
}

