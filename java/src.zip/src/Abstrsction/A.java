package Abstrsction;

public class A {

}



