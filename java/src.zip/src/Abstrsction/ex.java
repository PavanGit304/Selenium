package Abstrsction;

public class ex extends A {
	
	
	ex()
	{
		
		System.out.println("ex");
	}
	
public void Sree()
	
	{
		System.out.print("Swathi");
		
	}

	
	
	public static void main(String[]args)
	{
		
		ex obj = new ex();
		obj.Sree();
		
		
		
		//System.out.println("B");
	}

}


class A
{
	public void Sree()
	
	{
		
		System.out.print("Reddy");
		
	}

A()
{
	System.out.println("A");
}
}
