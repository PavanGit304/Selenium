package Abstrsction;

public class abstr {

	// Abstraction : it hides the implementation showing the functionalities to the user or it is a method of hiding the unwanted information and it cannot be initiated  but it can be inherited using extend keyword 
	//Abstract class : it contains both abstract and concrete methods and constructor and it have final method 
	public static void main(String args[]){  
		Rectangle obj=	new Rectangle ();  // it executes Rectangle class method
		obj.draw();
		obj.m1();
		
		new Circle1().draw();   // it executes  Circle1 class method
		
	}
}


abstract class Shape{  
abstract void draw();  // abstract method:it is declared with abstract keyword,it contains only method declaration and its implementation must be provided in derived class

Shape()  // Abstract class constructor 
{
	int a=10;
	System.out.println("abstract class constructor " +a);	
}
public void m1()   // Concrete method 
{
	int b =20;
System.out.println("Concrete method"+b);	
}

}

//final int speedlimit=90;   //final variable : if a variable declared final, you cannot change the value of final variable(It will be constant).
//void run(){  
// speedlimit=400;  
//}  
//}  


//class Bike{  
//	  final void run(){System.out.println("running");}   // Final method: final method cannot be override and final method can inherited 
//	}  
//	     
//	class Honda extends Bike{  
//	   void run(){System.out.println("running safely with 100kmph");} 



//final class Bike{                                               // Final Class: final class cannot be extended 
//	void run1(){System.out.println("running safely with 50kmph");}  
//}  
//
//class Honda1 extends Bike{  
//  void run(){System.out.println("running safely with 100kmph");}  

 
class Rectangle extends Shape{  
void draw()
{
	String name ="QA";
	System.out.println("drawing rectangle" +name) ; //abstract method implementation 
}  
}

class Circle1 extends Shape{  
void draw(){
	int noofstudents = 8;
	System.out.println("drawing circle"+noofstudents);
	}
}



