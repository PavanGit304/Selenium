package variables;


public class variables {  // variables are used to store the information/data value
	public static void main(String[]args){
		
		
		   ex obj = new ex();   // or new ex().m1();
			obj.m1();
		
			System.out.println("static variable :"+ex.s );
//			obj.m2();
																																																																										
				}}

		class ex{
			int i=10; // instance variable:a variable which is declared inside the class & outside the method/constructor/block is called instance variable and it created when an object is created with use of "new" keyword and it can accessible for all methods/constructors/blocks with in the class 
			
			static int s=20; 
			/*static variable:a variable which is declared inside the class & outside the method with static keyword 
			 static members and member functions can access globally without creating  an instance of a class or it initialized only once, when the execution started 
			*/
		 void m1(){
			// local variable: a variable which is declared inside the class & inside the method/constructor/block is known as local variable and it only accessible inside the method/constructor/block
			int L; // variable declaration 
			L=12;// Assigning the value
			System.out.println("local variable :"+L+ "\n" +"insatance variable :"+i+"\n");
		}
		
		
		// int a=10; variables are used to store data values  they are 3 types instance , local, static variable 
		
		}
	
	


