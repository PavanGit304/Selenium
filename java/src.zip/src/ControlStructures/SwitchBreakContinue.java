package ControlStructures;

import java.util.Scanner;

public class SwitchBreakContinue 
{
	public static void main(String[]arg)
	{

int age =20;

switch(age) //It is like if-else-if ladder statement. switch statement executes one statement from multiple conditions
{
case 15:
	System.out.println("your are not eligible for vote");
	break;
case 18:
	System.out.println("now you can vote");
	break;
case 150:
    System.out.println("is it your real age");
    break;
    default:
   
    	System.out.println("none");   	
}}
}
	
//	m1();
	
//	for(int i=1;i<=10;i++){  
//        if(i==5){  
//            //using continue statement  
//            continue;//it will skip the rest statement  
//        }  
//        System.out.println(i);  
//    } 
//


//Scanner sc= new Scanner(System.in);
//System.out.println("enter the age");
//age=sc.nextInt();
	
		

