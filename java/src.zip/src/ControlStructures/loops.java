package ControlStructures;

import java.util.Scanner;

public class loops 
{
public static void main(String[]args)
{
	
//	forDisplay(array);
//	foreachDisplay(array);

//int n=10;
//for (int a=0;(a<n);a++) { 
////for/iteration loop : it iterate the process many no.of times if the no.of iteration is fixed then use for loop	
//System.out.println("for a="+a);	
//}
/* int a=0;(initialization)
 * (a<n)   (condition)
 * a++   increment
 * */

	
	
//System.out.println("------------------------------------------------------------------------------------");
//
//int a=0;
//while(a<10)//it iterate the process many no.of time if the no.of iteration are not fixed then use while
//{
//a++;
//System.out.println("while a="+a);
//}







System.out.println("------------------------------------------------------------------------------------");

int i=0;
do //if the condition is true or false it will execute at least one time   
{
	System.out.println("do while a="+i);
i++;	
}while(i<10);







//
//System.out.println("------------------------------------------------------------------------------------");
//
//
//
//}
//
//
//static int[] array = { 1,2,3,4}; // static data member
//
//
//
//public static void forDisplay(int[] a) {  
//System.out.println("Display an array using for loop");
//for (int i = 0; i < a.length; i++) {
//   System.out.print(a[i] + " ");
//}
//System.out.println();
//}
//public static void foreachDisplay(int[] data) {
//System.out.println("Display an array using for each loop");
//for (int a  : data) { //foreach loop : It is mainly used to traverse/cross array or collection elements.
//   System.out.print(a+ " ");
//}
}
}

