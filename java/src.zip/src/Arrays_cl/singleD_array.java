qpackage Arrays_cl;

public class singleD_array { 
/*Array: it is collection of elements with same data type and fixed length and
	it stores multiple values in a single variable */

	public static void main(String args[]) {
		SingleD obj = new SingleD();
		obj.m1();
		twoD ob = new twoD();
		ob.m2();
		ob.m3();
	}
}

class SingleD { // 1D Array
	void m1() {
		String [] a = { "pavan", "roopa", "Tumuku" };
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}

/*for (String i : a) { System.out.println(i); } for-each loop : it iterate each
	element of an array and the collection*/

	}
}

/*2D Array :The data is stored in row and column based on index (also known as
 * matrix form) note: 1st it starts with rows(1st for loop) and then col(2nd/inner for loop)*/
class twoD{
	
	void m2() {
		  int[][] arr = { { 1, 2 }, { 3, 4 } };
		  
		  for (int i=0; i<2;i++) {
			  for (int j=0; j<2;j++) { 
			System.out.println("arr[0][0] = " + arr[0][0]);	
	        System.out.println("arr[0][1] = " + arr[0][1]);	
	        System.out.println("arr[1][0] = " + arr[1][0]);	
	        System.out.println("arr[1][1] = " + arr[1][1]);	
//	        System.out.println("arr[" 
//                    + i + "]["
//                    + j + "]="
//                    + arr[i][j]);
	        
			  }
		  }
	}
	

	void m3() {

//		int [][] ar = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
//
//		for (int i = 0; i < 3; i++) {
//			for (int j = 0; j < 3; j++) {
//				System.out.println(ar[i][j] + "");
//			}
//			System.out.println();
//		}
		
		int[][] arr = { { 1, 2 }, { 3, 4 } };
		  
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
               // System.out.print(arr[i][j] + " ");
            	  System.out.println("\n"+"arr[" 
                          + i + "]["
                          + j + "]="
                          + arr[i][j]);
            }
  
            System.out.println();
        }

	}
}
