package Arrays_cl;

public class ex1 {

	public static void main(String [] args) {
	
	  int[][] arr = { { 1, 2 }, { 3, 4 } };
		  
		  for (int i=0; i<2;i++) {
			  for (int j=0; j<2;j++) { 
			 				  
//	        System.out.println("arr[0][0] = " + arr[0][0]);	
//	        System.out.println("arr[0][1] = " + arr[0][1]);	
//	        System.out.println("arr[1][0] = " + arr[1][0]);	
//	        System.out.println("arr[1][1] = " + arr[1][1]);	
	        System.out.println("arr[" +i +"]["+ j + "]="+ arr[i][j]);
			}
		}
		  
	}}

