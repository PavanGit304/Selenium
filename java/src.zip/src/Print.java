
public class Print {

	public static void main(String[] args) {

		Print obj = new Print();
		obj.method1();
	}

	public void method1() {
		String name;
		name = "Hi";

		System.out.print(name);
	}

}
