package Constructors;

public class defaultConstructor {
	int a;
	public static void main(String[]arg){
		defaultConstructor  obj = new defaultConstructor();
		defaultConstructor  obj1 = new defaultConstructor();
	}
	
	// Default constructor (no-arg constructor): If we do not create any constructor, the Java compiler automatically 
	//create a no-arg constructor during the execution of the program

	private   defaultConstructor () { 
			a=10; // Set the initial value for the class attribute a
		System.out.println(a);
	}
	
	
	
	/*Constructor: it is a special method that is used to initialize objects. The constructor is called when an instance 
	 * of class is created or object of a class is created and it set initial values for object attributes.
	 *  Every time an object is created using the new() keyword and by using class name we can declare constructor 
	*/
}


