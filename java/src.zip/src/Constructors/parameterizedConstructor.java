package Constructors;

//Parameterized Constructor: A Constructor with arguments(or parameters) is known as Parameterized constructor. 
public class parameterizedConstructor {
//	int id;  
//    String name;  
    //creating a parameterized constructor  
    parameterizedConstructor(int i,String n){  
//    id = i;  
//    name = n;
    System.out.println(i+" "+n);
    }  
    //method to display the values  
    //void display(){}  
   
    public static void main(String args[]){  
    //creating objects and passing values  
    	parameterizedConstructor s1 = new parameterizedConstructor(111,"Karan");  
    	parameterizedConstructor s2 = new parameterizedConstructor(222,"Aryan");  
    	parameterizedConstructor s3 = new parameterizedConstructor(333,"pavan");
    //  calling method to display the values of object  
   //   s1.display();  
  //    s2.display();

}
}
