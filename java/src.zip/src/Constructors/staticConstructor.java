package Constructors;

public class staticConstructor {

}
