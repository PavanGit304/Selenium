package Inheritance;

public class hybrid_inher {
	

}


