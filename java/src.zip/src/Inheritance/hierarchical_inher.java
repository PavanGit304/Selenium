package Inheritance;

public class hierarchical_inher {
	
	public static void main(String[]args){
		class3 obj = new class3();
		obj.m1();
		obj.m3();
		
		class2 obj1 = new class2();
		obj1.m1();
		obj1.m2();
	}
}


class class1{
	public void m1() {System.out.println("class 1 m1");}	
}
class class2 extends class1{
	public void m2() {System.out.println("class 2 m2");	}
}
class class3 extends class1{
	public void m3() {System.out.println("class 3 m3");}	
}

/*
 hierarchical_inher: one parent class inherited by the many sub class 
 class A{}
 class B extends A{}
 class C extends A{} 
 */