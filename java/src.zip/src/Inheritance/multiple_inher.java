package Inheritance;

public class multiple_inher {
	
	public static void main(String[]args){
		mult obj = new mult();
		obj.m1();
		obj.m2();
		obj.m3();
	}
}

interface classA { // interface
	public void m1();
}
interface classB{
	public void m2();	
}
interface classC{
	public void m3();	
}

class mult implements classA, classB, classC {   //multiple inheritance 

	@Override
	public void m3() {
	System.out.println("class C m3");	
	}

	@Override
	public void m2() {
		System.out.println("class B m2");	
	}
	
	@Override
	public void m1() {
		System.out.println("class A m1");	
	}}


/*
 Multiple inheritance : a class can inherits more then one parent class java cannot supports
 multiple inheritance but by using interface concept we can achieve multiple inheritance 
 interface : it contains only method declaration and its implementation must be provided by the derived class   
 it cannot be initiated  but it can be inherited by using implement keyword 
 */