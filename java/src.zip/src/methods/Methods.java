package methods;

public class Methods 
{
	public static void main(String[]args){
		Methods obj = new Methods(); // method: is a block of code or collection of statements  to perform a certain task and it can use many times or it have code reuseability
		obj.m1();
		
		Methods.m2();//static method and  method calling  
	}
	
	void m1()  // instance method :we can call the instance method by using object creation
	{
	System.out.println("instance method");
	}	

	static void m2() // static method : we can call the static method by using class name
	{
		
		System.out.println("static method");	
	}

	/* predefined and user defined  methods 
	 * predefined method:predefined methods are already defined in the Java class libraries is known as predefined methods. 
	 * It is also known as the standard library method or built-in method.We can directly use these methods by calling method
	 *  name ex:length(), equals(), compareTo(),
	 * user defined method:The method written by the user or programmer is known as a user-defined method.and it modified 
	 * according to the requirement. it contains 2 types instance and static methods 
	 */
	
}
