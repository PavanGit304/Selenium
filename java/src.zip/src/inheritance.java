
public class inheritance {

}
