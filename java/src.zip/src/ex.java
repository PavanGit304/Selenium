
public class ex {
	
	public static void main(String []args) {
		ex seleniumclass = new ex(); // object
		seleniumclass.m1();
		
	String a="hi";
	System.out.println(a);
	}
	
	void m1()
	{
		System.out.println("hello");
	}
}
