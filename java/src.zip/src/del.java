
public class del {

	
	
	public static void main(String[]pavanargs) 
	{
		del obj = new del();
		obj.m1();
	}
	int c ;
	 public int m1() 
	{
		
		 int a =10;
		 int b= 20;
		 
	System.out.println("a+b ="+c);
		return c=a+b;
		
		
	}

	
  }
  