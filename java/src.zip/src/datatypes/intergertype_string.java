package datatypes;

public class intergertype_string {
	
	public static void main(String[]args) 
	{
		String print = "Hello world";
		System.out.println(print);	
	}
	

}
