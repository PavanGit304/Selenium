package datatypes;

public class intergertype_float {

	public static void main(String []args) {
	float a = 15.1f;
	System.out.println(a);
	}
}
