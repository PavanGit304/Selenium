package datatypes;

public class intergertype_double {
	
	public static void main(String []args) {
	double a = 20.44d;
	System.out.println(a);	

}
}
