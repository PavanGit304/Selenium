package datatypes;

public class intergertype_char {
	
	public static void main(String[]args) 
	{
		char a = 'A';
		System.out.println(a);	
	}
	

}
