package datatypes;

public class intergertype_short {
	
	public static void main(String []args) {
    short a = 5000;
	System.out.println(a);
	}

}
