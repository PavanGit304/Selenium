package datatypes;

public class intergertype_long {

	public static void main(String []args) {
	long a = 12000000000L;
	System.out.println(a);
	}
}
