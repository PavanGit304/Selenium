package datatypes;

public class intergertype_byte {
	
	public static void main(String[]args) 
	{
		byte a = 10;
		System.out.println(a);	
	}
	
}
