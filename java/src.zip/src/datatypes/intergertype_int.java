package datatypes;

public class intergertype_int {
	
	public static void main(String []args) {
	int  a = 1500000;
	System.out.println(a);
	}

}
