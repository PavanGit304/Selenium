package datatypes;

public class intergertype_boolean {
	public static void main(String[]args) 
	{
		boolean a = true;
		System.out.println(a);	
	}
	

}
