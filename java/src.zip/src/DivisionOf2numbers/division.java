package DivisionOf2numbers;

public class division {
	
	
	public static void main(String[]args)
	{
		
		division obj = new division();
		obj.divi(10, 20);
	}
	
	
	
	public float divi(float a, float b)  // if we declare int it will return 0 and if we declare float then it return 0.5  
	{
		System.out.println(a/b);
		
		return a/b;
		
		
	}

}
