
public interface segw {
	void m1();
	

}
