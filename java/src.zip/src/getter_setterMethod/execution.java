package getter_setterMethod;

import Constructors.staticConstructor;

public class execution {
	
public static void main(String[]args)
{
	ex1.setter("pavan");
	System.out.println(ex1.getter() + ex1.get());
	
	
}
}
