//
//public class claA {
//
//	claA()
//	{
//		
//		System.out.println("a");
//	}
//	
//	void m1() {}
//}
//
//
class clsB //extends claA
{
	
clsB(){	System.out.println("B");}

public static void main(String[]args) 
{
//	claA obj = new clsB();
//	obj.m1();
	
	System.out.println("B");
}





}

