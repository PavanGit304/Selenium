
public class abstraction 
{

}
